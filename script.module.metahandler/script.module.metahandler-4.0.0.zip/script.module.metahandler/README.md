# script.module.metahandler
Metahandler Script Module for Kodi

Scrape movie and tv show meta data within your own addons
